﻿#!/usr/bin/env pwsh
Write-Host "=== Tabular MCP Server Installation ===" -ForegroundColor Cyan
Write-Host ""
Write-Host "This script will help you set up the Tabular MCP Server." -ForegroundColor Green
Write-Host ""

Write-Host "Step 1: Checking prerequisites..." -ForegroundColor Yellow

# Check if Power BI Desktop processes are running
$pbiProcesses = Get-Process -Name "PBIDesktop" -ErrorAction SilentlyContinue
if ($pbiProcesses.Count -eq 0) {
    Write-Host "WARNING: Power BI Desktop is not running!" -ForegroundColor Red
    Write-Host "Please start Power BI Desktop and open a PBIX file, then run this script again." -ForegroundColor Yellow
    Read-Host "Press Enter to exit"
    exit 1
} else {
    Write-Host "Found $($pbiProcesses.Count) Power BI Desktop instance(s) running." -ForegroundColor Green
}

Write-Host ""
Write-Host "Step 2: Running Power BI discovery..." -ForegroundColor Yellow

# Change to app directory and run discovery
Set-Location "$PSScriptRoot\app"
& ".\pbi-local-mcp.exe" discover-pbi

if ($LASTEXITCODE -eq 0) {
    Write-Host ""
    Write-Host "Setup completed successfully!" -ForegroundColor Green
    Write-Host ""
    Write-Host "Next steps:" -ForegroundColor Yellow
    Write-Host "1. Copy this path: $PSScriptRoot\app\pbi-local-mcp.exe" -ForegroundColor White
    Write-Host "2. Add MCP configuration to VS Code (.vscode/mcp.json)" -ForegroundColor White
    Write-Host "3. See docs\DEPLOYMENT.md for detailed instructions" -ForegroundColor White
} else {
    Write-Host ""
    Write-Host "Setup failed. Please check:" -ForegroundColor Red
    Write-Host "- Power BI Desktop is running" -ForegroundColor Yellow
    Write-Host "- A PBIX file is open" -ForegroundColor Yellow
    Write-Host "- No firewall is blocking the connection" -ForegroundColor Yellow
}

Write-Host ""
Read-Host "Press Enter to continue"
